# -*- coding: utf-8 -*-
"""Inhalte der Vollbild-Sequenz."""
import getpass
import platform
import random
import shutil
import socket

_FILES = [
    r"C:\Windows\System32\config\SAM",
    r"C:\Windows\System32\drivers\etc\hosts",
    r"C:\Windows\System32\lsass.exe",
    r"C:\Users\Public\Documents\geheim.docx",
    r"C:\ProgramData\backup_sql.bak",
    r"D:\Buchhaltung\rechnungen_2026.xlsx",
    r"D:\Projekte\vertraege.pdf",
    r"D:\Freigaben\kundenliste.csv",
]

_TARGETS = [
    "rechnung_2026.xlsx", "personaldaten.docx", "buchhaltung.zip",
    "vertraege.pdf", "kundenliste.csv", "tokens.txt",
    "passwoerter.kdbx", "backup_sql.bak", "geheim.docx",
]

_REG_KEYS = [
    r"HKLM\SYSTEM\CurrentControlSet\Services\WinDefend",
    r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System",
    r"HKCU\Software\Microsoft\Windows\CurrentVersion\Run",
    r"HKLM\SOFTWARE\Policies\Microsoft\Windows Defender",
    r"HKLM\SYSTEM\CurrentControlSet\Control\SafeBoot",
]


def _host():
    try:
        return socket.gethostname()
    except Exception:
        return "DESKTOP"


def _user():
    try:
        return getpass.getuser()
    except Exception:
        return "User"


def phase_connect(ui):
    ui.line("[*] Sequenz initialisiert", "cyan")
    ui.sleep(0.5)
    ui.line("[*] Zielrechner   : " + _host())
    ui.sleep(0.2)
    ui.line("[*] Benutzerkonto : " + _user())
    ui.sleep(0.2)
    ui.line("[*] Betriebssystem: " + platform.platform())
    ui.sleep(0.2)
    try:
        total_gb = shutil.disk_usage("C:").total // (1024 ** 3)
        ui.line("[*] Datentraeger  : %d GB" % total_gb)
    except Exception:
        pass
    ip = "%d.%d.%d.%d" % (
        random.randint(11, 223), random.randint(0, 255),
        random.randint(0, 255), random.randint(1, 254),
    )
    ui.sleep(0.3)
    ui.line("[*] Command-and-Control: " + ip + ":443", "cyan")
    ui.sleep(0.4)
    ui.line("[+] Verbindung hergestellt", "cyan")
    ui.sleep(0.5)
    ui.line("[!] Echtzeit-Schutz deaktiviert", "red")
    ui.sleep(0.7)


def phase_scan(ui):
    ui.line("[*] Suchlauf gestartet ...", "cyan")
    ui.sleep(0.3)
    for pct in range(0, 101, 2):
        if not ui.running:
            return
        ui.progress("Durchsuche " + random.choice(_FILES), pct)
        if pct == 40:
            ui.line("[+] 3.482 Dokumente indiziert", "yellow")
        elif pct == 80:
            ui.line("[+] 12.901 Zugangsdaten gefunden", "yellow")
        ui.sleep(0.05)
    ui.sleep(0.5)


def phase_encrypt(ui):
    ui.line("[!] Ransomware-Modus aktiv", "red")
    ui.sleep(0.4)
    for pct in range(0, 101, 2):
        if not ui.running:
            return
        name = random.choice(_TARGETS)
        ui.progress("AES-256: " + name, pct)
        if pct % 10 == 0:
            ui.line("      " + name + "  ->  " + name + ".locked", "gray")
        ui.sleep(0.05)
    ui.sleep(0.3)
    ui.line("[!] Alle Dateien verschluesselt", "red")
    ui.sleep(0.7)


def phase_registry(ui):
    ui.line("[!] Registry wird manipuliert", "red")
    ui.sleep(0.4)
    for i in range(0, 101, 5):
        if not ui.running:
            return
        ui.progress("Schreibe " + random.choice(_REG_KEYS), i)
        ui.sleep(0.12)
    ui.sleep(0.2)
    ui.line("[!] Ausfuehrungsrichtlinien deaktiviert", "red")
    ui.sleep(0.5)


def phase_mbr(ui):
    ui.line("[!!!] Zugriff auf physikalischen Datentraeger", "red")
    ui.sleep(0.6)
    for pct in range(0, 101, 4):
        if not ui.running:
            return
        ui.progress("Schreibe Master Boot Record (Cylinder 0, Sector 0)",
                    pct)
        ui.sleep(0.05)
    ui.sleep(0.2)
    ui.line("[!!!] Bootsektor ueberschrieben", "red")
    ui.sleep(0.8)


def phase_matrix(ui):
    for _ in range(45):
        if not ui.running:
            return
        ui.matrix_step()
        ui.sleep(0.05)


def phase_bsod(ui):
    """1:1-Bluescreen mit Fortschrittszähler (Simulation)."""
    if not ui.running:
        return
    ui.bsod()
    pct = 0
    while ui.running and pct < 100:
        pct = min(100, pct + random.randint(1, 3))
        ui.crash_pct(pct)
        ui.sleep(random.uniform(0.12, 0.34))
    ui.sleep(1.3)
    ui.black()
    ui.sleep(1.4)


def phase_reboot(ui):
    if not ui.running:
        return
    ui.reboot()
    frames = "|/-\\"
    for i in range(30):
        if not ui.running:
            return
        ui.set_last("Neustart " + frames[i % 4] + " " + "." * (i % 4))
        ui.sleep(0.12)
    ui.stop()
