# -*- coding: utf-8 -*-
"""Vollbild-UI auf allen Monitoren (tkinter, immer im Vordergrund)."""
import ctypes
import random
import time
import tkinter as tk
from ctypes import wintypes

HWND_TOPMOST = ctypes.c_void_p(-1)
SWP_NOMOVE = 0x0002
SWP_NOSIZE = 0x0001
SWP_NOACTIVATE = 0x0010
_REASSERT_MS = 350

_user32 = ctypes.windll.user32
_user32.SetWindowPos.argtypes = [
    wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
    ctypes.c_int, ctypes.c_int, wintypes.UINT,
]
_user32.SetWindowPos.restype = wintypes.BOOL
_user32.GetParent.argtypes = [wintypes.HWND]
_user32.GetParent.restype = wintypes.HWND


def _root_hwnd(win):
    """Echtes Top-Level-Fenster (winfo_id liefert nur ein Child-Fenster)."""
    h = wintypes.HWND(win.winfo_id())
    parent = _user32.GetParent(h)
    return parent if parent else h

_TAGS = (
    ("red", "#ff453a"),
    ("yellow", "#ffd60a"),
    ("gray", "#8e8e93"),
    ("white", "#ffffff"),
    ("cyan", "#64d2ff"),
)


def monitor_rects():
    rects = []
    cbtype = ctypes.WINFUNCTYPE(
        ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p,
        ctypes.POINTER(wintypes.RECT), ctypes.c_ssize_t,
    )

    def _cb(hmon, hdc, lprect, lparam):
        r = lprect.contents
        rects.append((r.left, r.top, r.right, r.bottom))
        return 1

    cb = cbtype(_cb)
    _user32.EnumDisplayMonitors(None, None, cb, 0)
    if not rects:
        rects = [(0, 0, 1920, 1080)]
    return rects


class Screens:
    def __init__(self, visible=True, speed=1.0):
        self.visible = visible
        self.speed = speed
        self.running = True
        self._tick = 0
        self._has_lines = False
        self.root = tk.Tk()
        self.root.withdraw()
        self.root.title("System")
        self.root.protocol("WM_DELETE_WINDOW", lambda: None)
        self._wins = []
        self._texts = []
        self._sizes = []
        self._rects = []
        self._crash = []
        for left, top, right, bottom in monitor_rects():
            width = right - left
            height = bottom - top
            self._sizes.append((width, height))
            self._rects.append((left, top))
            win = tk.Toplevel(self.root)
            win.overrideredirect(True)
            win.attributes("-topmost", True)
            win.configure(bg="black")
            win.withdraw()
            win.geometry("%dx%d" % (width, height))
            size = max(11, min(26, height // 42))
            txt = tk.Text(
                win, bg="black", fg="#00ff41", font=("Consolas", size),
                borderwidth=0, highlightthickness=0, padx=24, pady=20,
                wrap="word", insertwidth=0,
            )
            txt.pack(fill="both", expand=True)
            txt.configure(state="disabled")
            for name, color in _TAGS:
                txt.tag_configure(name, foreground=color)
            if not visible:
                win.withdraw()
            self._wins.append(win)
            self._texts.append(txt)
        if visible:
            for win in self._wins:
                win.deiconify()
        try:
            self.root.update()
        except tk.TclError:
            pass
        for win, (left, top) in zip(self._wins, self._rects):
            _user32.SetWindowPos(
                _root_hwnd(win), HWND_TOPMOST,
                left, top, 0, 0,
                SWP_NOSIZE | SWP_NOACTIVATE,
            )
        self.root.bind_all("<Escape>", self._on_escape)
        self.root.bind_all("<Alt-F4>", lambda e: "break")
        for win in self._wins:
            win.bind("<Escape>", self._on_escape)
            win.bind("<Alt-F4>", lambda e: "break")
        self._reassert()

    def _on_escape(self, event):
        self.stop()
        return "break"

    def _reassert(self):
        if not self.running:
            return
        self._tick += 1
        for win, (left, top) in zip(self._wins, self._rects):
            try:
                win.lift()
                if self.visible:
                    _user32.SetWindowPos(
                        _root_hwnd(win), HWND_TOPMOST,
                        left, top, 0, 0,
                        SWP_NOSIZE | SWP_NOACTIVATE,
                    )
            except tk.TclError:
                pass
        if self.visible and self._tick % 4 == 0 and self._wins:
            try:
                self._wins[0].focus_force()
            except tk.TclError:
                pass
        try:
            self.root.after(_REASSERT_MS, self._reassert)
        except tk.TclError:
            self.running = False

    def line(self, text="", tag=None):
        if not self.running:
            return
        self._has_lines = True
        for txt in self._texts:
            try:
                txt.configure(state="normal")
                if tag:
                    txt.insert("end", text + "\n", tag)
                else:
                    txt.insert("end", text + "\n")
                txt.see("end")
                txt.configure(state="disabled")
            except tk.TclError:
                self.running = False
                return
        try:
            print(text)
        except Exception:
            pass

    def set_last(self, text, tag=None):
        if not self.running:
            return
        if not self._has_lines:
            self.line(text, tag)
            return
        for txt in self._texts:
            try:
                txt.configure(state="normal")
                start = txt.index("end-2c linestart")
                txt.delete(start, "end")
                if tag:
                    txt.insert("end", text + "\n", tag)
                else:
                    txt.insert("end", text + "\n")
                txt.see("end")
                txt.configure(state="disabled")
            except tk.TclError:
                self.running = False
                return

    def progress(self, label, pct):
        pct = max(0, min(100, int(pct)))
        filled = int(round(pct * 30 / 100.0))
        bar = "#" * filled + "-" * (30 - filled)
        self.set_last("[%s] %3d%%  %s" % (bar, pct, label))

    def clear(self):
        if not self.running:
            return
        for txt in self._texts:
            try:
                txt.configure(state="normal")
                txt.delete("1.0", "end")
                txt.configure(state="disabled")
            except tk.TclError:
                self.running = False
                return
        self._has_lines = False

    def set_theme(self, bg, fg):
        if not self.running:
            return
        for win, txt in zip(self._wins, self._texts):
            try:
                win.configure(bg=bg)
                txt.configure(bg=bg, fg=fg)
            except tk.TclError:
                self.running = False
                return

    def matrix_step(self, glyphs="01ABCDEF#$%&*+=<>/\\{}[]"):
        if not self.running:
            return
        for txt in self._texts:
            try:
                row = "".join(random.choice(glyphs)
                              for _ in range(random.randint(40, 90)))
                txt.configure(state="normal")
                txt.insert("end", row + "\n")
                txt.see("end")
                txt.configure(state="disabled")
            except tk.TclError:
                self.running = False
                return
        self.pump()

    def bsod(self, stopcode="CRITICAL_PROCESS_DIED"):
        """Exakte Nachbildung des Windows-Bluescreens (1:1 Layout)."""
        if not self.running:
            return
        self._drop_crash()
        self.clear()
        self.set_theme("#0078d7", "#ffffff")
        bg = "#0078d7"
        fg = "#ffffff"
        para = ("Dein PC hat ein Problem gefunden und muss neu gestartet "
                "werden. Wir sammeln gerade Fehlerinformationen und "
                "starten dann für Sie neu.")
        info = ("Weitere Informationen zu diesem Problem und möglichen "
                "Lösungen finden Sie unter\n"
                "https://www.windows.com/stopcode\n\n"
                "Wenn Sie den Support kontaktieren, geben Sie diese "
                "Informationen weiter:\n\nStoppcode: " + stopcode)
        for win, (w, h) in zip(self._wins, self._sizes):
            s = max(0.7, min(2.4, h / 1080.0))
            f_sad = max(24, int(64 * s))
            f_body = max(10, int(20 * s))
            f_small = max(9, int(15 * s))
            left = int(w * 0.09)
            top = int(h * 0.09)
            frame = tk.Frame(win, bg=bg)
            frame.place(x=0, y=0, relwidth=1, relheight=1)
            sad = tk.Label(frame, text=":(", font=("Segoe UI", f_sad),
                           bg=bg, fg=fg)
            body = tk.Label(frame, text=para, font=("Segoe UI", f_body),
                            bg=bg, fg=fg, justify="left",
                            wraplength=int(min(w * 0.62, 980 * s)))
            pct = tk.Label(frame, text="0% abgeschlossen",
                           font=("Segoe UI", f_body), bg=bg, fg=fg)
            qr_px = int(110 * s)
            qr = self._qr(frame, qr_px)
            side = tk.Label(
                frame, text=info, font=("Segoe UI", f_small),
                bg=bg, fg=fg, justify="left",
                wraplength=int(min(
                    w - 2 * left - qr_px - int(34 * s), 860 * s)),
            )
            frame.update_idletasks()
            y = top
            sad.place(x=left, y=y)
            y += sad.winfo_reqheight() + int(26 * s)
            body.place(x=left, y=y)
            y += body.winfo_reqheight() + int(34 * s)
            pct.place(x=left, y=y)
            y += pct.winfo_reqheight() + int(56 * s)
            qr.place(x=left, y=y)
            side.place(x=left + qr_px + int(34 * s), y=y + int(4 * s))
            self._crash.append((frame, pct))

    def crash_pct(self, pct):
        """Fortschrittsanzeige des Bluescreens aktualisieren."""
        if not self.running:
            return
        text = "%d%% abgeschlossen" % max(0, min(100, int(pct)))
        for _frame, lbl in self._crash:
            try:
                lbl.configure(text=text)
            except tk.TclError:
                self.running = False
                return

    def _drop_crash(self):
        for frame, _lbl in self._crash:
            try:
                frame.destroy()
            except tk.TclError:
                pass
        self._crash = []

    def _qr(self, parent, px):
        """QR-Code-Nachbildung (25x25 Module, echte Finder-Patterns)."""
        n, quiet = 25, 1
        cells = n + quiet * 2
        cv = tk.Canvas(parent, width=px, height=px, bg="#ffffff",
                       highlightthickness=0, borderwidth=0)
        m = px / cells
        rnd = random.Random(0x5EED)

        def dark(r, c):
            for orow, ocol in ((0, 0), (0, 18), (18, 0)):
                dr, dc = r - orow, c - ocol
                if 0 <= dr <= 7 and 0 <= dc <= 7:
                    if dr == 7 or dc == 7:
                        return False
                    if dr in (0, 6) or dc in (0, 6):
                        return True
                    return 2 <= dr <= 4 and 2 <= dc <= 4
            if r == 6 or c == 6:
                return (r + c) % 2 == 0
            if 16 <= r <= 20 and 16 <= c <= 20:
                d = max(abs(r - 18), abs(c - 18))
                return d in (0, 2)
            return rnd.random() < 0.47

        for r in range(n):
            for c in range(n):
                if dark(r, c):
                    x0 = (c + quiet) * m
                    y0 = (r + quiet) * m
                    cv.create_rectangle(x0, y0, x0 + m + 0.5, y0 + m + 0.5,
                                        fill="#000000", width=0)
        return cv

    def black(self):
        """Bildschirm schwarz (Übergang nach dem Bluescreen)."""
        if not self.running:
            return
        self._drop_crash()
        self.clear()
        self.set_theme("black", "black")

    def reboot(self):
        if not self.running:
            return
        self._drop_crash()
        self.clear()
        self.set_theme("black", "#00ff41")
        self.line("Windows wird neu gestartet...")
        self.line("")

    def sleep(self, seconds):
        deadline = time.monotonic() + seconds * self.speed
        while self.running and time.monotonic() < deadline:
            self.pump()
            if not self.running:
                return
            time.sleep(0.03)

    def pump(self):
        if not self.running:
            return
        try:
            self.root.update()
        except tk.TclError:
            self.running = False

    def stop(self):
        if not self.running:
            return
        self.running = False
        for win in self._wins:
            try:
                win.destroy()
            except tk.TclError:
                pass
        try:
            self.root.destroy()
        except tk.TclError:
            pass
