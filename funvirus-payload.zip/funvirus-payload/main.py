# -*- coding: utf-8 -*-
"""Vollbild-Sequenz auf allen Monitoren.

Start:        python main.py
Selbsttest:   python main.py --selftest   (unsichtbar, schnell)
Beenden:      ESC

Ab 100% zeigt die Sequenz einen exakt nachgebauten Bluescreen
(Fortschrittszähler, Stoppcode, QR) und danach die Neustart-Animation.
Reine Simulation - der Rechner startet nicht neu, nichts wird verändert.
"""
import ctypes
import sys

import phases
from ui import Screens

PHASEN = (
    phases.phase_connect,
    phases.phase_scan,
    phases.phase_encrypt,
    phases.phase_registry,
    phases.phase_mbr,
    phases.phase_matrix,
    phases.phase_bsod,
    phases.phase_reboot,
)


def _dpi_aware():
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
        return
    except Exception:
        pass
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass


def _stdio():
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def run(ui, verbose=False):
    for phase in PHASEN:
        if verbose:
            print("-- " + phase.__name__)
        phase(ui)
        if not ui.running:
            return


def main():
    selftest = "--selftest" in sys.argv[1:]
    ui = Screens(visible=not selftest,
                 speed=0.03 if selftest else 1.0)
    try:
        run(ui, verbose=selftest)
    except KeyboardInterrupt:
        pass
    finally:
        ui.stop()
        ui.pump()
    if selftest:
        print("SELFTEST OK")
    return 0


if __name__ == "__main__":
    _dpi_aware()
    _stdio()
    raise SystemExit(main())
